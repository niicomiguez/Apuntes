#!/usr/bin/env python3
import argparse
import string
import random
import sys

def comprobar_contrasena(pwd):
    """
    Chequea si la contraseña cumple los requisitos del apartado 3.4.1.
    """
    if len(pwd) < 8:
        return False
        
    if '"' in pwd or "'" in pwd or ' ' in pwd:
        return False

    letras = 0
    mayusculas = 0
    minusculas = 0
    numeros = 0
    simbolos = 0
    conteo_letras = {}

    for char in pwd:
        if char in string.ascii_uppercase:
            mayusculas += 1
            letras += 1
            conteo_letras[char] = conteo_letras.get(char, 0) + 1
        elif char in string.ascii_lowercase:
            minusculas += 1
            letras += 1
            conteo_letras[char] = conteo_letras.get(char, 0) + 1
        elif char in string.digits:
            numeros += 1
        elif char in string.punctuation:
            simbolos += 1

    if letras < 4:
        return False
        
    for count in conteo_letras.values():
        if count > 2:
            return False
            
    if mayusculas < 1 or minusculas < 1 or numeros < 1 or simbolos < 1:
        return False

    return True

def generar_contrasena():
    """
    Genera una contraseña aleatoria descartando las que no cumplen los requisitos.
    """
    caracteres_validos = [c for c in string.printable if c not in " '\"\t\n\r\x0b\x0c"]
    
    while True:
        longitud = random.randint(8, 12)
        pwd = ''.join(random.choice(caracteres_validos) for _ in range(longitud))
        
        if comprobar_contrasena(pwd):
            return pwd

def main():
    parser = argparse.ArgumentParser(description="Generador y chequeador de contraseñas.")
    
    grupo = parser.add_mutually_exclusive_group()
    grupo.add_argument("-c", type=int, metavar="NUM", help="Chequea NUM contraseñas")
    grupo.add_argument("-g", type=int, metavar="NUM", help="Genera NUM contraseñas aleatorias")
    
    parser.add_argument("-f", type=str, dest="fichero", help="Fichero de entrada/salida")
    
    args = parser.parse_args()

    if len(sys.argv) == 1:
        print(generar_contrasena())
        return

    # MODO CHEQUEADOR
    if args.c is not None:
        if args.fichero:
            try:
                with open(args.fichero, 'r') as f:
                    for _ in range(args.c):
                        linea = f.readline()
                        if not linea:
                            break
                        pwd = linea.replace('\n', '').replace('\r', '')
                        if comprobar_contrasena(pwd):
                            print(f"{pwd} SI")
                        else:
                            print(f"{pwd} NO")
            except FileNotFoundError:
                print(f"Error: No se ha encontrado el fichero {args.fichero}")
                sys.exit(1)
        else:
            # Leer de la entrada estándar y evaluar inmediatamente
            for _ in range(args.c):
                linea = sys.stdin.readline()
                if not linea:
                    break
                pwd = linea.replace('\n', '').replace('\r', '')
                
                # Se añade \t para replicar la indentación de la imagen
                if comprobar_contrasena(pwd):
                    print(f"\t{pwd} SI")
                else:
                    print(f"\t{pwd} NO")

    # MODO GENERADOR
    elif args.g is not None:
        contrasenas_generadas = [generar_contrasena() for _ in range(args.g)]
        
        if args.fichero:
            try:
                with open(args.fichero, 'w') as f:
                    for pwd in contrasenas_generadas:
                        f.write(f"{pwd}\n")
            except IOError:
                print(f"Error al escribir en {args.fichero}")
                sys.exit(1)
        else:
            for pwd in contrasenas_generadas:
                print(pwd)

if __name__ == "__main__":
    main()
