#!/usr/bin/env python3
import argparse
import sys

def comprobar_balance(secuencia):
    suma = 0
    for caracter in secuencia:
        if caracter == '(':
            suma += 1
        elif caracter == ')':
            suma -= 1
        
        # Si la suma es negativa, hay un paréntesis de cierre sin abrir
        if suma < 0:
            return False
            
    # Si al final la suma es 0, balanceados
    return suma == 0

def main():
    parser = argparse.ArgumentParser(description="Comprueba si una secuencia de paréntesis está balanceada.")
    parser.add_argument("fichero", help="Ruta al fichero de texto con los paréntesis")
    args = parser.parse_args()

    try:
        with open(args.fichero, 'r') as file:
            for linea in file:
                secuencia = linea.strip()
                
                if not secuencia:
                    continue
                
                if comprobar_balance(secuencia):
                    print(f"{secuencia} SI")
                else:
                    print(f"{secuencia} NO")
                    
    except FileNotFoundError:
        print(f"Error: No se ha encontrado el fichero {args.fichero}")
        sys.exit(1)

if __name__ == "__main__":
    main()
