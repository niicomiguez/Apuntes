#!/bin/bash

# Extraer título y tamaño con etiqueta del DISCO
awk '{print $5, $3, "DISCO1"}' $1 > temp1.txt
awk '{print $5, $3, "DISCO2"}' $2 > temp2.txt

# Unir temporales pasando a mayúsculas y ordenando por el título
cat temp1.txt temp2.txt | tr '[:lower:]' '[:upper:]' | sort > temp_todos.txt

# Pasar películas malas a mayúsculas y ordenar
tr '[:lower:]' '[:upper:]' < $3 | sort > temp_malas.txt

# Comparar archivos ordenados para excluir películas malas
join -v 1 temp_todos.txt temp_malas.txt

# Borrar ficheros temporales
rm temp1.txt temp2.txt temp_todos.txt temp_malas.txt
